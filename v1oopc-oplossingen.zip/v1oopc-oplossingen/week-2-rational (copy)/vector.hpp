#ifndef VECTOR_HPP
#define VECTOR_HPP

/// @file

/// \brief
/// vector ADT
/// \details
/// This is an ADT that implements vector values.
/// The x and y are stored as two vectors.
/// The appropriate constructors and operators are provided.
class vector {
private:
    int x;
    int y;
public:
   /// \brief
   /// constructor from explicit values
   /// \details
   /// This constructor initializes the vectors x and y.
    vector( int x, int y ):
        x( x ), y( y ){}
   /// \brief   
   /// compare two vectors
   /// \details
   /// This operator tests for equality. It returns true
   /// if and only if the x and y of both
   /// operands are equal.
    bool operator==( const vector & rhs ) const {
      return ( x == rhs.x ) && ( y == rhs.y );
   }
   /// \brief   
   /// add a vector to a vector
   /// \details
   /// This operator+ adds a vector to a vector.
    vector operator+( const vector & rhs ) const {
        return vector ( x + rhs.x, y + rhs.y );
    }
   /// \brief   
   /// add a vector to another vector
   /// \details
   /// This operator+= adds a vector to a vector.
    vector & operator+=( const vector & rhs ) {
        x += rhs.x;
        y += rhs.y;
        return *this;
    }
   /// \brief   
   /// multiply an integer by a vector
   /// \details
   /// This operator* multiplies an integer value by a vector.
    friend vector operator*( const int & lhs, vector & rhs ) {
      return vector( 
         lhs * rhs.x,
         lhs * rhs.y
      );
   }
   /// \brief   
   /// multiply a vector by an integer
   /// \details
   /// This operator* multiplies a vector by an integer value.
   friend vector operator*(  vector & lhs, const int & rhs ) {
      return vector( 
         lhs.x * rhs,
         lhs.y * rhs
      );
   }
   /// \brief   
   /// multiplies a vector by another vector
   /// \details
   /// This operator*= multiplies a vector by a vector.
   vector & operator*=( const vector & rhs ){
      x = x * rhs.x;
      y *= rhs.y;
      return *this;
   }
   /// \brief
   /// output operator for a vector
   /// \details
   /// This operator<< prints a constructor in the format
   /// [x/y] where both values are printed as
   /// decimal values.
   friend std::ostream & operator<<( std::ostream & lhs, const vector & rhs ){
      return lhs 
         << "[" 
         << rhs.x 
         << "/" 
         << rhs.y
         << "]";
   }   
};

#endif