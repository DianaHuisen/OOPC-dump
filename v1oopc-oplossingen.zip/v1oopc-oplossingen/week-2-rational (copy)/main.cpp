#define CATCH_CONFIG_MAIN 
#include <catch2/catch.hpp>

#include "ostream"
#include "vector.hpp"

TEST_CASE( "constructor, two_parameters, incl stringstream" ){
   vector v( 3, 4 );
   std::stringstream s;
   s << v;
   REQUIRE( s.str() == "[3/4]" );   
}

TEST_CASE( "equality, equal" ){
   vector v( 1, 2 );
   REQUIRE( v == vector( 1, 2 ) ); 
}

TEST_CASE( "equality, unequal" ){
   vector v( 1, 2 );
   REQUIRE( ! ( v == vector( 1, 3 )) ); 
}

TEST_CASE( "constructor, two_parameters" ){
   vector v( 10, 2 );
   REQUIRE( v == vector( 10, 2 ) ); 
}

TEST_CASE( "multiply by integer; vector int" ){
   vector v( 3, 4 );
   vector x = v * 7;
   REQUIRE( v == vector( 3, 4 ) ); 
   REQUIRE( x == vector( 21, 28 ) );   
}
TEST_CASE( "multiply by integer; int vector" ){
   vector v( 3, 10 );
   vector x = 5 * v;
   REQUIRE( v == vector ( 3, 10 ) );   
   REQUIRE( x == vector(15, 50 ) );  
}

TEST_CASE( "add vector to vector" ){
   vector v( 3, 10 );
   v += vector( 6, 7 ); 
   REQUIRE( v == vector( 9, 17 ) );     
}

TEST_CASE( "add vector to vector; return value" ){
   vector v( 1, 2 );
   vector x = ( v += vector( 1, 4 )); 
   REQUIRE( v == vector( 2, 6 ) );     
   REQUIRE( x == vector( 2, 6 ) );     
}

TEST_CASE( "multiply vector by vector" ){
   vector v( 3, 10 );
   v *= vector( 1, 2 ); 
   REQUIRE( v == vector( 3, 20 ) );     
}

TEST_CASE( "multiply vector by vector; return value" ){
   vector v( 3, 10 );
   vector x = ( v *= vector( 1, 2 )); 
   REQUIRE( x == vector( 3, 20 ) );     
}

TEST_CASE( "adds value to other value" ){
   vector v( 3, 4 );
   vector x = v + v;
   REQUIRE( v == vector( 3, 4 ) ); 
   REQUIRE( x == vector( 6, 8 ) );  
}






