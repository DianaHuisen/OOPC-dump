// example:
// a rectangle object that is contains four line objects

#include <iostream>
#include "book.hpp"

int main(int argc, char **argv){
    
//    int c = 17;
    std::string d = "Hallo";
    std::string e("Hallo2");
    std::string f{"Hallo3"};
    
    book b("Inhoud ", "Boek B Boekermans", "Mijn boek");
    b.print();
    
    
    std::cout << std::endl;
}
