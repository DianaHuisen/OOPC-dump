#include <iostream>
#include "furniture.hpp"

void stool::print(){
    std::cout << "Number of leggies: " << n_legs << "\n";
    std::cout << "Number of seats: " << n_seats << "\n";
}

void stool::removeLeg(){
    n_legs=n_legs-1;    
}

void table::print(){
    std::cout << "Number of table leggies: " << n_legs << "\n";
    std::cout << "Length of table: " << length << "\n";
    std::cout << "Width of table: " << width << "\n";
}

void table::addLegs(){
    n_legs=n_legs+4;
}

void furniture::print(){
    table1.print();
    stool1.print();
    stool2.print();
    stool3.print();
    stool4.print();
}

void furniture::makeMoreHipster(){
    table1.addLegs();
    stool1.removeLeg();
    stool2.removeLeg();
    stool3.removeLeg();
    stool4.removeLeg();
}