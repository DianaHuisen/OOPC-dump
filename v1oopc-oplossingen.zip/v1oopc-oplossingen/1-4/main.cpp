#include <iostream>
#include "furniture.hpp"

int main(int argc, char **argv){
    furniture ikea{};
    ikea.print();
    ikea.makeMoreHipster();
    std::cout<<"after the change: \n";
    ikea.print();
}
