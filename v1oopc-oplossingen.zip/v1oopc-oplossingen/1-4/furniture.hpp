#ifndef FURNITURE_HPP
#define FURNITURE_HPP



class stool{
private:
    int n_legs;
    int n_seats;
    
public:
    stool(
        const int & n_legs,
        const int & n_seats
    ) :
        n_legs(n_legs),
        n_seats(n_seats)
    {}

    void removeLeg();
    void print();
};

class table{
private:
    int n_legs;
    int length;
    int width;
    
public:
    table(
        const int & n_legs,
        const int & length,
        const int & width
    ) : 
        n_legs(n_legs),
        length(length),
        width(width)
    {}

    void addLegs();
    void print();
};


class furniture{
    stool stool1, stool2, stool3, stool4;
    table table1;

public:
    furniture() : stool1(stool(4, 1)), stool2(stool(3, 1)), stool3(stool(6, 2)), stool4(stool(8, 1)), table1(table(4, 120, 180)) {}

    void makeMoreHipster();
    void print();
};


#endif // FURNITURE_HPP