#include <hwlib.hpp>

int main(void){
WDT->WDT_MR=WDT_MR_WDDIS;
auto led4=hwlib::target::pin_out(hwlib::target::pins::d4);
auto led5=hwlib::target::pin_out(hwlib::target::pins::d5);
auto led6=hwlib::target::pin_out(hwlib::target::pins::d6);
auto led7=hwlib::target::pin_out(hwlib::target::pins::d7);

auto leds = hwlib::port_out_from_pins_t(led4,led5,led6,led7);

while(true){
leds.write(7);
}
}