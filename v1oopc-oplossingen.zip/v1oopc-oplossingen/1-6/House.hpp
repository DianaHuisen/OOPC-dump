#ifndef HOUSE_HPP
#define HOUSE_HPP

#include "rectangle.hpp"

class House{
private:
    hwlib::window & w;
    int c1,c2,c3,c4,amount;
public:
    House(hwlib::window & w, int amount);
    void print();
};


#endif // HOUSE_HPP