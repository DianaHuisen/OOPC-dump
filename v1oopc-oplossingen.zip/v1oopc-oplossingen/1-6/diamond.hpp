// example:
// declaration of a rectangle object that is contains four line objects

#ifndef DIAMOND_HPP
#define DIAMOND_HPP

#include "rectangle.hpp"
class diamond {
private:
   hwlib::window & w;
   rectangle left, right, top, bottom;
public:
   diamond( hwlib::window & w, int start_x, int start_y, int end_x, int end_y );
   void print();
};


#endif // DIAMOND_HPP
