#include "House.hpp"

House::House( hwlib::window & w, int amount):
    w(w),
    c1(20),
    c2(20),
    c3(40),
    c4(40),
    amount(amount)
   
{}

void House::print(){
        while (amount > 0){
        line roofDiag1(w, c1+1,c2-1,c3-14,c4-26);
        roofDiag1.print();
        line roofDiag2(w, c1+15,c2-5,c3,c4-20);
        roofDiag2.print();  
        line roofTop(w, c1+6,c2-6,c3-5,c4-26);
        roofTop.print();
        line roofMid(w, c1+3,c2-3,c3-3,c4-23);
        roofMid.print();  

        rectangle square( w, c1, c2, c3, c4 );
        square.print();
        hwlib::circle window(hwlib::xy(c1+6,c2+8), 3);
        window.draw(w);
        rectangle curtains( w, c1+2, c2+4, c3-10, c4-8 );
        curtains.print();   
        rectangle door( w, c1+12, c2+10, c3-3, c4 );
        door.print();
        hwlib::circle doorKnob(hwlib::xy(c1+15,c2+15), 1);
        doorKnob.draw(w);   

            if (amount ==1){
                break;
            }
            else{
                amount--;
                c1+=22;
                c3+=22;
            }
    }
     w.flush();
}