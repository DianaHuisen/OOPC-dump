#include <iostream>
#include "House.hpp"

int main(int argc, char **argv){
    
   hwlib::target::window w( 128, 64 );
   House many(w,4);
   many.print();
   for(;;){ w.poll(); }       
}