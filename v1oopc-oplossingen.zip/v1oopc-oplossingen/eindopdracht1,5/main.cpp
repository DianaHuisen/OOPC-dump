#include "hwlib.hpp"

namespace target = hwlib::target;
   

struct buttons{
   
    target::board board; 
 
    const int red = 1;
    const int green = 2;
    const int blue = 3;
    const int black = 4;
    
    int get_button(){
      board.sw1.refresh();
      board.sw2.refresh();
      board.sw3.refresh();
      board.sw4.refresh();
   
        if (board.sw2.read()){
            return red;
        }
   
        if (board.sw3.read()){
            return green;
        }   
    
        if (board.sw4.read()){
            return blue;
        }

        if (board.sw1.read()){
            return black;
        }
    
        return 0;
    }
};

struct rightWrong{
    target::board board;
    hwlib::all_from_pin_out_t leds = hwlib::all(
      board.led1, board.led2, board.led3, board.led4, 
      board.led5, board.led6, board.led7, board.led8, board.led9 );
      
    void wrong(){
        board.red.write(1);
        board.green.write (0);
        board.blue.write (0);
        leds.write(1);
    }
    void right(){
        board.red.write(0);
        board.green.write (1);
        board.blue.write (0);
        leds.write(1);
    }
    void victory(){
        leds.write( 1 );
        leds.flush();
        auto colors = hwlib::port_out_from( board.blue, board.red, board.green );
        hwlib::snake( colors, 200 );
    }
    void reset(){
        board.red.write(0);
        board.green.write (0);
        board.blue.write (0);
        leds.write(1);
    }
};

int main( void ){	
   target::board board;     
    buttons b;

std::array<int,9> order={b.green, b.red, b.blue, b.green, b.blue, b.red, b.blue, b.red, b.green};
unsigned int guessed =0;

rightWrong status;
    for(uint16_t i = 0; i < order.size();){
        int pressed = b.get_button();
        if(pressed == order[i]){
            status.right();
            if (guessed==i){
                guessed++;
            }
        }
        else if(pressed == b.black){
           status.reset();
           if (guessed > i){
                i++;
           }
        }
        else if(pressed != 0 && pressed != order[i]){
            status.wrong();
        }

        if (i== order.size()){
            status.victory();
            
        }
    }
}