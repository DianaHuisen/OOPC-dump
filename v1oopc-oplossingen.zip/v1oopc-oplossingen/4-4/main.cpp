#include <hwlib.hpp>

int main(void){
WDT->WDT_MR=WDT_MR_WDDIS;
int counter = 0;
auto led3=hwlib::target::pin_out(hwlib::target::pins::d3);
auto led4=hwlib::target::pin_out(hwlib::target::pins::d4);
auto led5=hwlib::target::pin_out(hwlib::target::pins::d5);
auto led6=hwlib::target::pin_out(hwlib::target::pins::d6);
auto in1=hwlib::target::pin_in(hwlib::target::pins::d8);
auto in2=hwlib::target::pin_in(hwlib::target::pins::d9);


auto leds = hwlib::port_out_from_pins_t(led3,led4,led5,led6);

while(true){
    if ((in1.read()==1 && counter !=4)){
        counter++;
    hwlib::wait_ms( 400 );
    }
    else if ((in2.read() == 1 && counter!=0)){
        counter--;
    hwlib::wait_ms( 400 );
    }
    leds.flush();
    if (counter ==4){
        leds.write(15);
    }
    else if (counter == 3){
        leds.write(7);
    }
    else if (counter == 2){
        leds.write(3);
    }
    else if (counter == 1){
        leds.write(1);
    }
    else if (counter == 0){
        leds.write(0);
    }
}
}