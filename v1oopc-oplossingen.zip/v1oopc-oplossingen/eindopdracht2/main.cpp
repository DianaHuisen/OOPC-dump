#include "hwlib.hpp"

// Hardware achter de button
class Button
{
private:
    hwlib::target::board board;
    unsigned int btn;
    
public:
    Button(const hwlib::target::board & board, const unsigned int & btn) : board(board), btn(btn){}
    
    bool pressed(){
        if (btn==0){
            return board.sw4.read(); //blue
        }
        else if (btn==1){
             return board.sw3.read(); //green
        }
        else if (btn==2){
             return board.sw2.read(); //red
        }
        else if (btn==3){
             return board.sw1.read(); //black
        }
        else{
            hwlib::cout << "Invalid Button" << hwlib::endl;
        }
    } 
};

//checkt of knop ingedrukt is
class InputController {
private:
public:
    InputController(Button blueBtn, Button<buttons>, GameController &gameCtrl);
    void UpdateButtons()
    {
        if(blueBtn.pressed())
        {
            gameCtrl.BluePressed();
        }
    }
};

class GameController
{
private:
    // Numbersss
    // currentNumberIndex
    
    bool CheckRow(unsigned int rowId)
    {
        if(numbers[currentNumberIndex])
        // If currentNumber is in row return true
        
        // else
        return false;// @TODO
    }
    
    void Correct(LEDRow row)
    {
        row.GreenOn();
        // SELECt NEXT NUMBER from 
        index++;
        if(index > numbers.size())
        {
            index = 0;
        }
        
    }
    
    void Incorrect(LEDRow row)
    {
        row.RedOn();
    }
    
    void Reset()
    {
        upRow.Off();
        midRow.Off();
        botRow.Off();
    }
    
public:
    // constructor
    // numberOfRows, volgorde van juiste ding, buttons, led rows
    
    
    void BluePressed()
    {
        if(CheckRow(0))
        {
            // CORRECT (0)
            Correct(upRow);
        }
        else
        {
            // incorrect (0)
        }
    }
    void GreenPressed()
    {
        CheckRow(1);
    }
    void RedPressed();
    void ResetPressed()
    {
        Reset();
    }
};

class LEDRow
{
private:
    //. pin
    hwlib::pin_out led1, led2, led3;
    
    void WriteLeds()
    {
        // Led1, led2, led3
        led1.write(1);
        led2.write(1);
        led3.write(1);
    }
    
public:

    LEDRow(l1,l2,l3)
    void GreenOn()
    {
        board.red.write(0);
        board.green.write(1);
        board.blue.write(0);
        
        // Led1, led2, led3
        WriteLeds();
    }
    void RedOn()
    {
        board.red.write(0);
        board.green.write(1);
        board.blue.write(0);
        WriteLeds();
    }
    void BlueOn()
    {
        board.red.write(0);
        board.green.write(1);
        board.blue.write(0);
        WriteLeds();
    }
    void Off()
    {
        board.red.write(0);
        board.green.write(1);
        board.blue.write(0);
        WriteLeds();
    }
};

int main(void){
    // numbers
//    std::array<int,3> ar={{1,9,5}};
    
    hwlib::target::board board;
    Button blueBtn = Button(board, 0);
    Button greenBtn = Button(board, 1);
    Button redBtn = Button(board, 2);
    Button resetBtn = Button(board, 3);
    
    LEDRow upRow = LEDRow(l1, l2, l3);
    LEDRow midRow = LEDRow(l4, l5, led6);
    LEDRow botRow = LEDRow(l7, l8, led9);
    
    GameController  gameCtrl = GameController(upRow, midRow, botRow, ar, )
    
        InputController inputCtrl = InputController(blueBtn, gameCtrl);
    

    
    inputCtrl.UpdateButtons();
}