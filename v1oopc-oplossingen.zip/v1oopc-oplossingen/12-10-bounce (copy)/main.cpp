#include <hwlib.hpp>
#include <array>
#include <unistd.h>
#include <iostream>

// ===========================================================================

class drawable {
protected:

   hwlib::window & w;
   hwlib::xy location;
  
   
public:
 hwlib::xy size;
   hwlib::xy bounce{1,1};
   bool invisible = true;
   drawable( hwlib::window & w, const hwlib::xy & location, const hwlib::xy & size ):
      w( w ),
      location( location ),
      size( size )
   {}      
   
   virtual void draw() = 0;
   virtual void update(){}
   bool overlaps( const drawable & other );   
   virtual void interact( drawable & other ){}
   
   hwlib::ostream & print( hwlib::ostream & out ) const {
      return out << location << " " << ( location + size );
   }      
};

hwlib::ostream & operator<<( hwlib::ostream & lhs, const drawable & rhs ){
   return rhs.print( lhs );
}

bool within( int x, int a, int b ){
   return ( x >= a ) && ( x <= b );
}

bool drawable::overlaps( const drawable & other ){
   
   bool x_overlap = within( 
      location.x, 
      other.location.x, 
      other.location.x + other.size.x
   ) || within( 
      other.location.x, 
      location.x, 
      location.x + size.x
   );
     
   bool y_overlap = within( 
      location.y, 
      other.location.y, 
      other.location.y + other.size.y
   ) || within( 
      other.location.y, 
      location.y, 
      location.y + size.y
   );
   
   return x_overlap && y_overlap;
}

// ===========================================================================

class line : public drawable {
private:

   hwlib::xy end;
   
public:

   line( hwlib::window & w, const hwlib::xy & location, const hwlib::xy & end ):
      drawable( w, location, end - location ),
      end( end )
   {}
   void moves(const hwlib::xy& shift) { location = location + shift; size = end-location; }
   void movee(const hwlib::xy& shift) { end = end + shift; size = end-location; }
   void draw() override {
      hwlib::line x( location, end );
      x.draw( w );;
   }
   void move(const hwlib::xy& shift){
	location = location + shift;
	end = end + shift;
   }
};

// ===========================================================================

class rectangle : public drawable {
protected:
	line top, left, right, bottom;
public:
	rectangle(hwlib::window&w, hwlib::xy start, hwlib::xy end):
	drawable(w, start, end - start),
	top(w, start, hwlib::xy(end.x, start.y)),
	left(w, start, hwlib::xy(start.x, end.y)),
	right(w, hwlib::xy(end.x, start.y), end),
	bottom(w, hwlib::xy(start.x, end.y), end)
	{
	}
	void draw() override{
		for(const auto& l : {&top, &left, &right, &bottom}){
			l->draw();		
		}
	};
};
class wall :public rectangle{
protected:
    bool fill=false;
    public:
	wall(hwlib::window&w, hwlib::xy start, hwlib::xy end):
	rectangle(w, start, end){}
	void draw() override{
        if(fill){
//            usleep(95000);
            fill=false;
//            for(const auto& l : {&top, &left, &right, &bottom}){
//                top.move(hwlib::xy{0,1});	
//                l->draw();
//                top.draw();
//                top.move(hwlib::xy{0,-1});
//                top.draw();
//                top.move(hwlib::xy{0,2});	
//                top.draw();
//                top.move(hwlib::xy{0,-2});
//                top.draw();
//                top.move(hwlib::xy{0,3});	
//                top.draw();
//                top.move(hwlib::xy{0,-3});
//                top.draw();
//                left.move(hwlib::xy{1,0});	
//                left.draw();
//                left.move(hwlib::xy{-1,0});
//                left.draw();
//                left.move(hwlib::xy{2,0});	
//                left.draw();
//                left.move(hwlib::xy{-2,0});
//                left.draw();
//                left.move(hwlib::xy{3,0});	
//                left.draw();
//                left.move(hwlib::xy{-3,0});
//                left.draw();
//            }
        }
        else{
//            usleep(95000);
//            fill=true;
            for(const auto& l : {&top, &left, &right, &bottom}){
                  l->draw();
                    l->move(hwlib::xy{0,0});
                }
            }
		};
};

// ===========================================================================

class circle : public drawable {
protected:

   int radius;
 
public:

   circle( hwlib::window & w, const hwlib::xy & midpoint, int radius ):
      drawable( w, 
         midpoint - hwlib::xy( radius, radius ), 
         hwlib::xy( radius, radius ) * 2 ),
      radius( radius )
   {}
   
   void draw() override {
      hwlib::circle c( location + hwlib::xy( radius, radius ), radius );
      c.draw( w );
   }
};

// victim

class victim : public drawable {
protected:
	line top, left, right, bottom;
public:
	victim(hwlib::window&w, hwlib::xy start, hwlib::xy end):
	drawable(w, start, end -start),
	top(w, hwlib::xy(start.x, start.y), hwlib::xy(end.x, start.y)),
	left(w, hwlib::xy(start.x, start.y), hwlib::xy(start.x, end.y)),
	right(w, hwlib::xy(end.x, start.y), hwlib::xy(end.x, end.y)),
	bottom(w, hwlib::xy(start.x, end.y), hwlib::xy(end.x, end.y))
	{
	}
	void draw() override{
		for(const auto& l : {&top, &left, &right, &bottom}){
			l->draw();		
		}
	};
    
    void interact( drawable & other ) override {
        if( this != & other){
              if( overlaps( other )&& !other.invisible && size.x >0 && size.y >0){
                top.moves(hwlib::xy(1,1));
                top.movee(hwlib::xy(-1,1));
                
                bottom.moves(hwlib::xy(1,-1));
                bottom.movee(hwlib::xy(-1,-1));
                
                left.moves(hwlib::xy(1,1));
                left.movee(hwlib::xy(1,-1));
                
                right.moves(hwlib::xy(-1,1));
                right.movee(hwlib::xy(-1,-1));
                size.x-=2;
                size.y-=2;
                location.x += 1;
                location.y += 1;
            }
        }
    }
};

// ===========================================================================

class ball : public circle {
private:

   hwlib::xy speed;
   
public:

   ball( 
      hwlib::window & w, 
      const hwlib::xy & midpoint, 
      int radius, 
      const hwlib::xy & speed 
   ):
      circle( w, midpoint, radius ),
      speed( speed )  {invisible=false;}
   
   void update() override {
      location = location + speed; 
   }
   
   
   void interact( drawable & other ) override {
      if( this != & other){
         if( overlaps( other )){
             speed.x*=other.bounce.x;
             speed.y*=other.bounce.y;
             
         }
      }
   }
   
};

// ===========================================================================

int main(){
   hwlib::target::window w( hwlib::xy( 128, 64 ), 2 );
   ball b( w, hwlib::xy( 50, 20 ), 9, hwlib::xy( 2, 1 ) );
   wall wa1(w, hwlib::xy( 0, 0 ),  hwlib::xy( 127, 4 ) );
   wall wa2(w, hwlib::xy( 123, 0 ),  hwlib::xy( 127, 63 ) );
   wall wa3(w, hwlib::xy( 0, 0 ),  hwlib::xy( 4, 63 ) );
   wall wa4(w, hwlib::xy( 0, 59 ),  hwlib::xy( 127, 63 ) );
   victim v(w, hwlib::xy( 20, 20 ), hwlib::xy( 50, 50 ));
   wa4.bounce.y= -1;
   wa1.bounce.y = -1;
   wa2.bounce.x = -1;
   wa3.bounce.x = -1;
std::array< drawable *, 6 > objects = { &v, &wa1, &wa2, &wa3, &wa4, &b };

   for(;;){
      w.clear();
      for( auto & p : objects ){
         p->draw();
      }
      w.flush();
      hwlib::wait_ms( 50 );
      for( auto & p : objects ){
          p->update();
      }
      for( auto & p : objects ){
         for( auto & other : objects ){
            p->interact( *other );
         } 
      }
   }
}

