#include <hwlib.hpp>

int main(void){
WDT->WDT_MR=WDT_MR_WDDIS;
auto led3=hwlib::target::pin_out(hwlib::target::pins::d3);
auto led4=hwlib::target::pin_out(hwlib::target::pins::d4);
auto led5=hwlib::target::pin_out(hwlib::target::pins::d5);
auto led6=hwlib::target::pin_out(hwlib::target::pins::d6);

auto leds = hwlib::port_out_from_pins_t(led3,led4,led5,led6);

while(true){
    
    
    for(uint8_t g : {12,6,3,6,12}){
        
        leds.write(g);
        hwlib::wait_ms( 200 );
    }
//leds.write(12);
//leds.flush();
//hwlib::wait_ms( 200 );
//leds.write(6);
//leds.flush();
//hwlib::wait_ms( 200 );
//leds.write(3);
//leds.flush();
//hwlib::wait_ms( 200 );
//leds.write(6);
//leds.flush();
//hwlib::wait_ms( 200 );
//leds.write(12);
//leds.flush();
//hwlib::wait_ms( 200 );
}
}