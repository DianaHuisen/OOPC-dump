#include "hwlib.hpp"
void wrong(){
    namespace target = hwlib::target;
   target::board board; 
    board.red.write(1);
    board.green.write (0);
    board.blue.write (0);
    auto leds = hwlib::all(
      board.led1, board.led2, board.led3, board.led4, 
      board.led5, board.led6, board.led7, board.led8, board.led9 );
    leds.write(1);
}
void correct(){
    namespace target = hwlib::target;
   target::board board; 
    board.red.write(0);
    board.green.write (1);
    board.blue.write (0);
    auto leds = hwlib::all(
      board.led1, board.led2, board.led3, board.led4, 
      board.led5, board.led6, board.led7, board.led8, board.led9 );
    leds.write(1);

}


int main( void ){	
   namespace target = hwlib::target;
   target::board board; 
   auto leds = hwlib::all(
      board.led1, board.led2, board.led3, board.led4, 
      board.led5, board.led6, board.led7, board.led8, board.led9 );

int count =0;
bool guessed =false;
//array<int,9> volgorde{9,1,4,3,6,7,5,8,1};
//array<bool,9> aanofuit{true, true, true, true, true, true, true,true, true}
//
//   void write_color(array<bool,9>, int color){
//       
//   }
//   const int cred = 0;
//   const int cgreen = 1;
//   const int cblue = 2;
//   write_color(aanofuit,cgreen);

   
   for(;;){
      board.sw1.refresh();
      board.sw2.refresh();
      board.sw3.refresh();
      board.sw4.refresh();

      if( board.sw1.read() ){
          if (guessed == true && count==0){
              count++;
              guessed=false;
          }
           board.red.write( 0);
           board.green.write (0);
           board.blue.write (0);
           board.led1.write(1);
      }
      if( board.sw2.read() ){ //red
         if (count==0){
            wrong();
          }
          if (count==1){
            correct();
            guessed=true;
          }
      }
      
      if( board.sw3.read() ){ //green
              wrong();
      }
      
      if( board.sw4.read() ){ //blue
          if (count==0){
            correct();
            guessed=true;
          }
         if (count==1){
            wrong();
          }

      }
   }
}