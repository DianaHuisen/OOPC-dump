#include "rectangleFill.hpp"


rectangleFill::rectangleFill( hwlib::window & w, int start_x, int start_y, int end_x, int end_y ):
   w( w ),
   left(   w, start_x, start_y, start_x,   end_y ),
   right(  w, end_x,   start_y, end_x,     end_y ),
   top(    w, start_x, start_y, end_x , start_y ),
   bottom( w, start_x, end_y,   end_x , end_y )
{}

void rectangleFill::print(){
   left.print();
   right.print();
   top.print();
   bottom.print();
}

filledRectangle::filledRectangle( hwlib::window & w, int start_x, int start_y, int end_x, int end_y ):
   w( w ),
   sX(start_x),
   sY(start_y),
   X(end_x+start_x),
   Y(end_y+start_y)
   {}
   
void filledRectangle::print(){
    for(int i=sX;i<X; i++){
        for(int j=sY;j<Y;j++){
            w.write(hwlib::xy{i,j});
        }
    }
    w.flush();
}