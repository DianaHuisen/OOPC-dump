// example:
// declaration of a rectangle object that is contains four line objects

#ifndef RECTANGLEFILL_HPP
#define RECTANGLEFILL_HPP

#include "rectangle.hpp"
class rectangleFill {
private:
   hwlib::window & w;
   rectangle left, right, top, bottom;
public:
   rectangleFill( hwlib::window & w, int start_x, int start_y, int end_x, int end_y );
   void print();
};

class filledRectangle {
private:
   hwlib::window & w;
   int sX,sY,X,Y;
public:
   filledRectangle( hwlib::window & w, int start_x, int start_y, int end_x, int end_y );
   void print();
};


#endif // RECTANGLEFILL_HPP
