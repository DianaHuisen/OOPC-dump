// example:
// a rectangle object that is contains four line objects

#include <iostream>
#include "rectangle.hpp"
#include "rectangleFill.hpp"

int main(int argc, char **argv){
   // the window in which we want to print the line
   hwlib::target::window w( 128, 64 );    
    
   int StartX=10;
   int StartY=20;
   int Lenght=1;
   int Height=2;


     filledRectangle square1( w, StartX, StartY, Lenght, Height );
     square1.print();
//   int c1=10;
//   int c2=20;
//   int c3=10;
//   int c4=40;
//   while (c1<=c3 && c2<=c4 && c3>=c1 && c4>=c2){
//       
//        rectangleFill square1( w, c1, c2, c3, c4 );
//       square1.print();
//
//        c1+=1;
//        c2+=1;
//        c3-=1;
//        c4-=1;
//   }
////fancy animated filling square^ 
//    w.flush();
   // keep the window around until we close it
   for(;;){ w.poll(); }       
    
   
   
}
