#include <hwlib.hpp>
class pin_out_invert : public hwlib::pin_out {
private:
   hwlib::pin_out & slave;
   
public:
   pin_out_invert( hwlib::pin_out & slave ): 
      slave( slave ){}
      
   void write( bool x ) override {
      slave.write( ! x );
   } 
   
   void flush() override { 
      slave.flush(); 
   }
   
};


class pin_out_all : public hwlib::pin_out {
private:
    std::array< hwlib::pin_out *, 8 > list;
public:
    pin_out_all(
        hwlib::pin_out & p0,
        hwlib::pin_out & p1 = hwlib::pin_out_dummy,
        hwlib::pin_out & p2 = hwlib::pin_out_dummy,
        hwlib::pin_out & p3 = hwlib::pin_out_dummy,
        hwlib::pin_out & p4 = hwlib::pin_out_dummy,
        hwlib::pin_out & p5 = hwlib::pin_out_dummy,
        hwlib::pin_out & p6 = hwlib::pin_out_dummy,
        hwlib::pin_out & p7 = hwlib::pin_out_dummy
    ):
        list { &p0, &p1, &p2, &p3, &p4, &p5, &p6, &p7 }
    {}
    void write (bool v) override {
        for ( auto p : list){
            p-> write (v);
        }
    }
    void flush() override{
        for (auto p : list){
            p-> flush();
        }
    }
};



int main(void){
WDT->WDT_MR=WDT_MR_WDDIS;
auto led1=hwlib::target::pin_out(hwlib::target::pins::d3);
auto led2=hwlib::target::pin_out(hwlib::target::pins::d4);
auto led3=hwlib::target::pin_out(hwlib::target::pins::d5);
auto led4=hwlib::target::pin_out(hwlib::target::pins::d6);
auto led5_pin=hwlib::target::pin_out(hwlib::target::pins::d8);
auto led6_pin=hwlib::target::pin_out(hwlib::target::pins::d9);
auto led7_pin=hwlib::target::pin_out(hwlib::target::pins::d10);
auto led8_pin=hwlib::target::pin_out(hwlib::target::pins::d11);
auto led5 = pin_out_invert( led5_pin );
auto led6 = pin_out_invert( led6_pin );
auto led7 = pin_out_invert( led7_pin );
auto led8 = pin_out_invert( led8_pin );

pin_out_all(led1, led2, led3,led4, led5, led6, led7, led8);
auto leds1 = pin_out_all(led1, led2, led3, led4, led5, led6, led7, led8);

    hwlib::blink ( leds1, 500 );
}