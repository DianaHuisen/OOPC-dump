#include <hwlib.hpp>

class pin_in_test : public hwlib::pin_in {
private:
     hwlib::pin_in& p0;
     hwlib::pin_in& p1;
   
public:
    pin_in_test(
        hwlib::pin_in & p0,
        hwlib::pin_in & p1
    ):
        p0( p0),p1( p1) { }
    
    bool read() override {
        if (p0.read() && p1.read()){
        return true;
        }    else{
        return false;
    }
    }
};

int main(void){
WDT->WDT_MR=WDT_MR_WDDIS;
auto led1=hwlib::target::pin_out(hwlib::target::pins::d3);
auto in1=hwlib::target::pin_in(hwlib::target::pins::d8);
auto in2=hwlib::target::pin_in(hwlib::target::pins::d9);

pin_in_test inpin(in1,in2);
while(true){
    if (inpin.read()){
        led1.write(1);
    }
    else{
        led1.write(0);
    }
}
}