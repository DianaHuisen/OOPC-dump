#include <hwlib.hpp>

int main(void){
    WDT->WDT_MR=WDT_MR_WDDIS;
    int counter = 0;
    auto led1=hwlib::target::pin_out(hwlib::target::pins::d3);
    auto led2=hwlib::target::pin_out(hwlib::target::pins::d4);
    auto led3=hwlib::target::pin_out(hwlib::target::pins::d5);
    auto led4=hwlib::target::pin_out(hwlib::target::pins::d6);
    auto in1=hwlib::target::pin_in(hwlib::target::pins::d8);
    auto in2=hwlib::target::pin_in(hwlib::target::pins::d9);
    auto ds   = hwlib::target::pin_out( hwlib::target::pins::d11 );
    auto stcp = hwlib::target::pin_out( hwlib::target::pins::d12 );
    auto shcp = hwlib::target::pin_out( hwlib::target::pins::d13 );
    auto spi  = hwlib::spi_bus_bit_banged_sclk_mosi_miso( 
        shcp, 
        ds, 
        hwlib::pin_in_dummy 
    );
   
    auto chipleds = hwlib::hc595( spi, stcp );
    auto leds = hwlib::port_out_from( 
      led1,
      led2, 
      led3,
      led4,
      chipleds.p0,
      chipleds.p1,
      chipleds.p2,
      chipleds.p3

   );

    while(true){
        
        if (( in1.read())&& ( counter < 8)){
            counter++;
        }
        else if ((in2.read()) && ( counter > 0)){
            counter--;
        }
        leds.write((1<<counter)-1);

        hwlib::wait_ms( 100 );
        leds.flush();
    }
}