#include <hwlib.hpp>
class pin_out_all : public hwlib::pin_out {
private:
    std::array< hwlib::pin_out *, 4 > list;
public:
    pin_out_all(
        hwlib::pin_out & p0,
        hwlib::pin_out & p1 = hwlib::pin_out_dummy,
        hwlib::pin_out & p2 = hwlib::pin_out_dummy,
        hwlib::pin_out & p3 = hwlib::pin_out_dummy
    ):
        list { &p0, &p1, &p2, &p3 }
    {}
    void write (bool v) override {
        for ( auto p : list){
            p-> write (v);
        }
    }
    void flush() override{
        for (auto p : list){
            p-> flush();
        }
    }
};


int main(void){
WDT->WDT_MR=WDT_MR_WDDIS;
auto led1=hwlib::target::pin_out(hwlib::target::pins::d3);
auto led2=hwlib::target::pin_out(hwlib::target::pins::d4);
auto led3=hwlib::target::pin_out(hwlib::target::pins::d5);
auto led4=hwlib::target::pin_out(hwlib::target::pins::d6);

auto led5=hwlib::target::pin_out(hwlib::target::pins::d8);
auto led6=hwlib::target::pin_out(hwlib::target::pins::d9);
auto led7=hwlib::target::pin_out(hwlib::target::pins::d10);
auto led8=hwlib::target::pin_out(hwlib::target::pins::d11);

pin_out_all(led1, led2, led3,led4);
auto leds1 = pin_out_all(led1, led2, led3,led4);
pin_out_all( led5, led6, led7, led8);
auto leds2 = pin_out_all( led5, led6, led7, led8);

auto kittLeds=hwlib::port_out_from(leds1, leds2);

while(true){
    
    hwlib::kitt(kittLeds, 200);

}
}