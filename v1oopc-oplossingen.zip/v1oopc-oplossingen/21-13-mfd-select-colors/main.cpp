#include "hwlib.hpp"

int main( void ){	
    
   namespace target = hwlib::target;
   target::board board; 
   auto leds = hwlib::all(
      board.led1, board.led2, board.led3, board.led4, 
      board.led5, board.led6, board.led7, board.led8, board.led9 );


int test = 2;
int count =0;
bool guessed =false;

//array<int,9> volgorde{9,1,4,3,6,7,5,8,1};
//array<bool,9> aanofuit{true, true, true, true, true, true, true,true, true}
//
//   void write_color(array<bool,9>, int color){
//       
//   }
//   const int cred = 0;
//   const int cgreen = 1;
//   const int cblue = 2;
//   write_color(aanofuit,cgreen);
   
   
   for(;;){
      board.sw1.refresh();
      board.sw2.refresh();
      board.sw3.refresh();
      board.sw4.refresh();

      if( board.sw1.read() ){
          if (guessed == true && count==0){
              count++;
              guessed=false;
          }
          test=0;
           board.red.write( 0);
           board.green.write (0);
           board.blue.write (0);
           board.led1.write(1);
           test= 2;
      }
      if (test == 5){
          board.red.write(1);
          board.green.write (0);
          board.blue.write (0);
          leds.write(1);
      }
      if( board.sw2.read() ){
         if (test==2 and count==0){
            test =5;
          }
          if (test==2 and count==1){
            board.red.write(0);
            board.green.write (1);
            board.blue.write (0);
            leds.write(1);
            board.led1.write(0);
            board.led7.write(1);
            guessed=true;
          }
      }
      
      if( board.sw3.read() ){
          if (test==2){
              test=5;
          }
      }
      
      if( board.sw4.read() ){
          if (test==2 && count==0){
            board.red.write(0);
            board.green.write (1);
            board.blue.write (0);
            leds.write(1);
            board.led1.write(0);
            board.led9.write(1);
            guessed=true;
          }
         if (test==2 && count==1){
            test=5;
          }
         else{
        hwlib::cout<<"test"<<test;
        hwlib::cout<<"counter?"<<count;
         board.red.write( 0);
         board.green.write (0);
         board.blue.write (1);
         leds.write(1);
         }

      }
        if (count ==0){
            if (test ==2){
                board.led1.write( 0 );
                board.blue.write ( 0 );
            }
            else{
                board.led1.write( test );
                board.blue.write ( test );
            }
        }
        else{
            if(test ==2){
                board.led9.write( 0 );
                board.blue.write ( 0 );
            }
            else{
                board.led9.write( test );
                board.blue.write ( test );
            }
        }
   }
}